import psycopg2
con = None

from PySide2.QtWidgets import *
def startConnection(user , senha):
    #Conectar no database
    global con
    try:
        con = psycopg2.connect(
            host = "localhost",
            database = "TrabalhoBD",
            user = str(user),
            password = str(senha),
            port = "5432"
        )
        con.autocommit = True
        return True
        #SE CONECTAR MUDA PARA TELA DASHBOARD
    except:
        msg = QMessageBox()
        msg.setWindowTitle("Aviso")
        msg.setText("Erro ao tentar conectar!!! ")
        x = msg.exec_()
        return False
def QueryTol(comando):
    print(comando)
    cmd = con.cursor()
    cmd.execute(comando)

def GetDate(comando):
    cmd = con.cursor()
    cmd.execute(comando)
    dad = cmd.fetchall()
    return dad

def ClosedConnection():
    con.close()
