# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'LoginjpZcyI.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from PySide2 import  QtCore
import  ConexaoComBD
con = ConexaoComBD


class Ui_MainWindow(object):
    #FUNCAO CHAMADA QUANDO CLICA NO BOTA DE ENTRAR
    def LoginUser(self):
        if not self.lineEdit.text() or not self.lineEdit_2.text():
            msg = QMessageBox()
            msg.setWindowTitle("Aviso")
            msg.setText("Digite o usuario e a senha")
            x = msg.exec_()
        else:
            user = self.lineEdit.text()
            senha = self.lineEdit_2.text()
            con.startConnection(user , senha)


    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"loginWindow")
        MainWindow.resize(640, 480)
        MainWindow.setStyleSheet(u"background-color: transparent;")
        MainWindow.setAttribute(Qt.WA_TranslucentBackground, True)
        flags = QtCore.Qt.WindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint)
        MainWindow.setWindowFlags(flags)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(180, 70, 281, 351))
        self.frame.setStyleSheet(u"background-color: rgb(40, 40, 40);\n"
"border-radius: 40px")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.lineEdit = QLineEdit(self.frame)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setGeometry(QRect(40, 90, 181, 21))
        self.lineEdit.setStyleSheet(u"background-color: transparent;\n"
"color: #717072;\n"
"border-bottom: 1px solid #717072")
        self.lineEdit_2 = QLineEdit(self.frame)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setGeometry(QRect(40, 150, 181, 21))
        self.lineEdit_2.setStyleSheet(u"background-color: transparent;\n"
"color: #717072;\n"
"border-bottom: 1px solid #717072")
        self.lineEdit_2.setEchoMode(QLineEdit.Password)
        self.pushButton = QPushButton(self.frame)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(80, 260, 113, 32))
        self.pushButton.setStyleSheet(u"background-color: rgb(252, 80, 7);\n"
"border-radius:10px")
        self.toolButton = QToolButton(self.centralwidget)
        self.toolButton.setObjectName(u"toolButton")
        self.toolButton.setGeometry(QRect(280, 30, 81, 81))
        self.toolButton.setStyleSheet(u"border-radius: 20px;\n"
"background-color: rgb(253, 101, 8);")
        icon = QIcon()
        icon.addFile(u"icons/login-icon-3048.png", QSize(), QIcon.Normal, QIcon.Off)
        self.toolButton.setIcon(icon)
        self.toolButton.setIconSize(QSize(50, 50))





        self.pushButton.clicked.connect(self.LoginUser)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi


    # retranslateUi

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    maindwindows = QMainWindow()
    window = Ui_MainWindow()
    window.setupUi(maindwindows)
    maindwindows.show()
    sys.exit(app.exec_())