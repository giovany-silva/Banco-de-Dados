import numpy
import matplotlib.pyplot as plt

def CreateGraficoBar(dados , labels):
    xG = []
    dadosG = []
    plt.style.use('ggplot')
    plt.ion()

    m = len(dados[0])
    for unityG in dados:
        xG.append(unityG[m -1])
    vec = numpy.array(xG)
    for cont in range(m - 1):
        for unity in dados:
            dadosG.append(unity[cont])
        vecDate = numpy.array(dadosG)
        plt.bar(vec , vecDate , label= labels[cont])
        dadosG.clear()

    plt.legend()
    plt.pause(3)
    plt.ioff()

def CreateGraficoPizza(dados , nomes):

    xG = []
    dadosG = []
    som = 0
    tot = []
    plt.style.use('ggplot')
    plt.figure(figsize=(7, 7))
    plt.ion()
    print(nomes)
    name = list(nomes)
    m = len(dados[0])
    for unityG in dados:
        xG.append(unityG[m - 1])

    for cont in range(m - 1):
        for unity in dados:
            dadosG.append(unity[cont])
        for i in dadosG:
            som = som + i
        tot.append(som)
    vec = numpy.array(tot)
    plt.pie(vec , labels= name , autopct= '%1.1f%%')
    plt.legend()
    plt.pause(3)
    plt.ioff()

def CreateGraficoBarHozizontal(dados , labels):
    xG = []
    dadosG = []
    plt.style.use('ggplot')
    plt.ion()
    m = len(dados[0])
    for unityG in dados:
        xG.append(unityG[m - 1])
    vec = numpy.array(xG)
    for cont in range(m - 1):
        for unity in dados:
            dadosG.append(unity[cont])
        vecDate = numpy.array(dadosG)
        plt.barh(vec , vecDate, label=labels[cont])
        dadosG.clear()

    plt.legend()
    plt.pause(3)
    plt.ioff()

