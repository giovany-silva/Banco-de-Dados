

import ConexaoComBD
con = ConexaoComBD
def Consultar(tabelaName , setorIndex):
    setorIndex = (setorIndex * 12) + 12
    base = setorIndex - 11
    dados = con.GetDate('select * from ' + str(tabelaName) + ' where id_setor >= '+str(base)+' and id_setor <= '+str(setorIndex) )
    return dados

def Consultar1(tabelaName , setorIndex , item1 , ano):
    setorIndex = (setorIndex * 12) + 12
    base = setorIndex - 11
    dados = con.GetDate(
        'select ' + str(tabelaName) + '.' + str(item1)  + ', setor.ano  from ' + str(
            tabelaName) + ' inner join setor on ' + str(tabelaName) + '.id_setor = setor.id_setor where ' + str(
            tabelaName) + '.id_setor >= ' + str(base) + ' and ' + str(tabelaName) + '.id_setor <= ' + str(
            setorIndex) + ' and setor.ano >= 2007 and setor.ano <= ' + str(ano))
    return dados
def Consultar2(tabelaName, setorIndex, item1 , item2 , ano):
    setorIndex = (setorIndex * 12) + 12
    base = setorIndex - 11
    print(str(item1) , str(item2) , str(tabelaName) , str(base) , str(setorIndex))
    dados = con.GetDate(
        'select ' + str(tabelaName) + '.' + str(item1) + ',' + str(tabelaName) + '.' + str(item2) + ', setor.ano  from ' + str(
            tabelaName) + ' inner join setor on ' + str(tabelaName) + '.id_setor = setor.id_setor where ' + str(
            tabelaName) + '.id_setor >= ' + str(base) + ' and '+ str(tabelaName) + '.id_setor <= ' + str(
            setorIndex) + ' and setor.ano >= 2007 and setor.ano <= ' + str(ano))
    return dados
def Consultar3(tabelaName, setorIndex, item1 , item2 , item3 , ano):
    setorIndex = (setorIndex * 12) + 12
    base = setorIndex - 11
    dados = con.GetDate(
        'select ' + str(tabelaName) + '.' + str(item1) + ',' + str(tabelaName) + '.' + str(item2) + ',' + str(
            tabelaName) + '.' + str(item3)  + ', setor.ano  from ' + str(
            tabelaName) + ' inner join setor on ' + str(tabelaName) + '.id_setor = setor.id_setor where ' + str(
            tabelaName) + '.id_setor >= ' + str(base) + ' and ' + str(tabelaName) + '.id_setor <=' + str(
            setorIndex) + ' and setor.ano >= 2007 and setor.ano <= ' + str(ano))
    return dados
def Consultar4(tabelaName, setorIndex, item1 , item2 , item3, item4 , ano):
    setorIndex = (setorIndex * 12) + 12
    base = setorIndex - 11
    dados = con.GetDate(
        'select ' + str(tabelaName) + '.' + str(item1) + ',' + str(tabelaName) + '.' + str(item2) + ',' + str(
            tabelaName) + '.' + str(item3) + ',' + str(tabelaName) + '.' + str(item4) + ', setor.ano  from ' + str(
            tabelaName) + ' inner join setor on ' + str(tabelaName) + '.id_setor = setor.id_setor where ' + str(
            tabelaName) + '.id_setor >= ' + str(base) + ' and ' + str(tabelaName) + '.id_setor <= ' + str(
            setorIndex) + ' and setor.ano >= 2007 and setor.ano <= ' + str(ano))
    return dados
def Consultar5(tabelaName, setorIndex, item1,  item2 , item3, item4, item5 , ano):
    setorIndex = (setorIndex * 12) + 12
    base = setorIndex - 11
    dados = con.GetDate(
        'select ' + str(tabelaName) + '.' + str(item1) + ',' + str(tabelaName) + '.' + str(item2) + ',' + str(
            tabelaName) + '.' + str(item3) + ',' + str(tabelaName) + '.' + str(item4) + ',' + str(
            tabelaName) + '.' + str(item5)  + ', setor.ano  from ' + str(
            tabelaName) + ' inner join setor on ' + str(tabelaName) + '.id_setor = setor.id_setor where ' + str(
            tabelaName) + '.id_setor >= ' + str(base) + ' and ' + str(tabelaName) + '.id_setor <=' + str(
            setorIndex) + ' and setor.ano >= 2007 and setor.ano <= ' + str(ano))
    return dados
def Consultar6(tabelaName, setorIndex, item1,  item2 , item3, item4, item5 , item6 , ano):
    setorIndex = (setorIndex * 12) + 12
    base = setorIndex - 11
    dados = con.GetDate(
        'select ' + str(tabelaName) + '.' + str(item1) + ',' + str(tabelaName) + '.' + str(item2) + ',' + str(
            tabelaName) + '.' + str(item3) + ',' + str(tabelaName) + '.' + str(item4) + ',' + str(
            tabelaName) + '.' + str(item5) + ',' + str(tabelaName) + '.' + str(
            item6) + ', setor.ano  from ' + str(
            tabelaName) + ' inner join setor on ' + str(tabelaName) + '.id_setor = setor.id_setor where ' + str(
            tabelaName) + '.id_setor >= ' + str(base) + ' and ' + str(tabelaName) + '.id_setor <=' + str(
            setorIndex) + ' and setor.ano >= 2007 and setor.ano <= ' + str(ano))
    return dados
def Consultar7(tabelaName, setorIndex, item1,  item2 , item3, item4, item5 , item6, item7 , ano):
    setorIndex = (setorIndex * 12) + 12
    base = setorIndex - 11
    dados = con.GetDate(
        'select ' +str(tabelaName)+'.'+str(item1) +  ',' +str(tabelaName)+'.'+str(item2) + ',' +str(tabelaName)+'.'+ str(item3) + ',' +str(tabelaName)+'.'+ str(item4) + ',' +str(tabelaName)+'.'+ str(item5) + ',' +str(tabelaName)+'.'+ str(
            item6) +','+str(tabelaName)+'.'+str(item7)+ ', setor.ano  from ' + str(tabelaName) + ' inner join setor on ' + str(tabelaName)+'.id_setor = setor.id_setor where '+str(tabelaName)+'.id_setor >= ' + str(base) + ' and '+str(tabelaName)+'.id_setor <= ' + str(setorIndex)+' and setor.ano >= 2007 and setor.ano <=' + str(ano) )
    return dados
